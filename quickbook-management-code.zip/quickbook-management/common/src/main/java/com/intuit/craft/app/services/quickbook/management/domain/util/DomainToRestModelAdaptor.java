package com.intuit.craft.app.services.quickbook.management.domain.util;

import com.intuit.craft.app.services.quickbook.management.contract.model.Address;
import com.intuit.craft.app.services.quickbook.management.contract.model.Customer;
import com.intuit.craft.app.services.quickbook.management.contract.model.Product;

import java.util.stream.Collectors;

public class DomainToRestModelAdaptor {

    public static Customer adapt(com.intuit.craft.app.services.quickbook.management.domain.Customer customerModel) {
        Customer customer = new Customer();
        customer.setCustomerId(customerModel.getCustomerId());
        customer.setEmail(customerModel.getEmail());
        customer.setName(customerModel.getName());
        if (customerModel.getAddress() == null)
            throw new RuntimeException("Invalid Address field");
        customer.setAddress(adapt(customerModel.getAddress()));
        if (customerModel.getProducts() != null)
            customer.setProduct(customerModel.getProducts().stream().map(DomainToRestModelAdaptor::adapt).collect(Collectors.toList()));
        return customer;
    }

    public static Address adapt(com.intuit.craft.app.services.quickbook.management.domain.Address addressRestModel) {
        Address address = new Address();
        address.setLine1(addressRestModel.getLine1());
        address.setLine2(addressRestModel.getLine2());
        address.setCity(addressRestModel.getCity());
        address.setState(addressRestModel.getState());
        address.setCountry(addressRestModel.getCountry());
        address.setZip(addressRestModel.getZip());
        return address;
    }

    public static Product adapt(com.intuit.craft.app.services.quickbook.management.domain.Product productModel) {
        Product product = new Product();
        product.setProductId(productModel.getProductId());
        product.setProductName(productModel.getProductName());
        product.setDescription(productModel.getDescription());
        product.setStatus(productModel.getStatus());
        return product;
    }
}
