package com.intuit.craft.app.services.quickbook.management.domain.util;

import com.intuit.craft.app.services.quickbook.management.domain.Address;
import com.intuit.craft.app.services.quickbook.management.domain.Customer;
import com.intuit.craft.app.services.quickbook.management.domain.Product;

import java.util.List;
import java.util.stream.Collectors;

public class RestToDomainModelAdaptor {

    public static Customer adapt(com.intuit.craft.app.services.quickbook.management.contract.model.Customer customerRest) {
        Customer customer = new Customer();
        customer.setEmail(customerRest.getEmail());
        customer.setName(customerRest.getName());
        if (customerRest.getAddress() == null)
            throw new RuntimeException("Invalid Address field");
        customer.setAddress(adapt(customerRest.getAddress()));
        if (customerRest.getProduct() != null)
            customer.setProducts(adapt(customerRest.getProduct()));
        return customer;
    }

    public static Address adapt(com.intuit.craft.app.services.quickbook.management.contract.model.Address addressRest) {
        Address address = new Address();
        address.setLine1(addressRest.getLine1());
        address.setLine2(addressRest.getLine2());
        address.setCity(addressRest.getCity());
        address.setState(addressRest.getState());
        address.setCountry(addressRest.getCountry());
        address.setZip(addressRest.getZip());
        return address;
    }

    private static List<Product> adapt(List<com.intuit.craft.app.services.quickbook.management.contract.model.Product> productRestList) {
        return productRestList.stream().
                map(product -> new Product(product.getProductId(), product.getProductName(), product.getDescription(), product.getStatus()))
                .collect(Collectors.toList());
    }

    public static Product adapt(com.intuit.craft.app.services.quickbook.management.contract.model.Product productRest) {
        Product product = new Product();
        product.setProductName(productRest.getProductName());
        product.setDescription(productRest.getDescription());
        product.setStatus(productRest.getStatus());
        return product;
    }
}
