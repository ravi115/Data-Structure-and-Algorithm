package com.intuit.craft.app.services.quickbook.management.rest.controller;

import com.intuit.craft.app.services.quickbook.management.api.ProductService;
import com.intuit.craft.app.services.quickbook.management.contract.api.ProductProfileApi;
import com.intuit.craft.app.services.quickbook.management.contract.model.Product;
import com.intuit.craft.app.services.quickbook.management.domain.util.DomainToRestModelAdaptor;
import com.intuit.craft.app.services.quickbook.management.domain.util.RestToDomainModelAdaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class ProductController implements ProductProfileApi {


    @Lazy
    @Autowired
    ProductService productService;

    @Override
    public ResponseEntity<List<Product>> getProducts(List<String> productIds) {
        List<com.intuit.craft.app.services.quickbook.management.domain.Product> productList = productIds.stream().map(productService::get).collect(Collectors.toList());
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(productList.stream().map(DomainToRestModelAdaptor::adapt).collect(Collectors.toList()));
    }


    @Override
    public ResponseEntity<Product> getProduct(String productId) {
        com.intuit.craft.app.services.quickbook.management.domain.Product product = productService.get(productId);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(DomainToRestModelAdaptor.adapt(product));
    }

    @Override
    public ResponseEntity<Product> onboardProduct(Product body) {
        com.intuit.craft.app.services.quickbook.management.domain.Product product = RestToDomainModelAdaptor.adapt(body);
        com.intuit.craft.app.services.quickbook.management.domain.Product productRes = productService.save(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(DomainToRestModelAdaptor.adapt(productRes));
    }

    @Override
    public ResponseEntity<List<Product>> getAllProducts() {
        List<com.intuit.craft.app.services.quickbook.management.domain.Product> productList = productService.getAll();
        List<Product> products = productList.stream().map(DomainToRestModelAdaptor::adapt).collect(Collectors.toList());
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(products);
    }
}
