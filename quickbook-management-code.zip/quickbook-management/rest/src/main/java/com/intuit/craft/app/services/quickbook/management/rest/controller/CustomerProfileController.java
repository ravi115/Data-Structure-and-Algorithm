package com.intuit.craft.app.services.quickbook.management.rest.controller;

import com.intuit.craft.app.services.quickbook.management.api.CustomerService;
import com.intuit.craft.app.services.quickbook.management.contract.api.CustomerProfileApi;
import com.intuit.craft.app.services.quickbook.management.contract.model.Customer;
import com.intuit.craft.app.services.quickbook.management.domain.util.DomainToRestModelAdaptor;
import com.intuit.craft.app.services.quickbook.management.domain.util.RestToDomainModelAdaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class CustomerProfileController implements CustomerProfileApi {

    @Lazy
    @Autowired
    CustomerService customerService;

    @Override
    public ResponseEntity<Customer> createCustomer(Customer body) {
        com.intuit.craft.app.services.quickbook.management.domain.Customer res = customerService.save(RestToDomainModelAdaptor.adapt(body));
        return ResponseEntity.status(HttpStatus.CREATED).body(DomainToRestModelAdaptor.adapt(res));
    }

    @Override
    public ResponseEntity<Customer> getCustomer(String customerId) {
        com.intuit.craft.app.services.quickbook.management.domain.Customer customer = customerService.get(customerId);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(DomainToRestModelAdaptor.adapt(customer));
    }

    @Override
    public ResponseEntity<Void> deleteCustomer(String customerId) {
        customerService.delete(customerId);
        return ResponseEntity.status(HttpStatus.ACCEPTED).build();
    }

    @Override
    public ResponseEntity<Customer> updateCustomer(Customer body, String customerId) {
        com.intuit.craft.app.services.quickbook.management.domain.Customer customer = customerService.update(RestToDomainModelAdaptor.adapt(body), customerId);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(DomainToRestModelAdaptor.adapt(customer));
    }

    @Override
    public ResponseEntity<List<Customer>> getAllCustomer() {
        List<com.intuit.craft.app.services.quickbook.management.domain.Customer> customerList = customerService.getAll();
        List<Customer> response = customerList.stream().map(DomainToRestModelAdaptor::adapt).collect(Collectors.toList());
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
    }
}
