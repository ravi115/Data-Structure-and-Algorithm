package com.intuit.craft.app.services.quickbook.management.rest.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication(scanBasePackages = {
        "com.intuit.craft.app.services.quickbook.management.rest",
        "com.intuit.craft.app.services.quickbook.management.impl",
        "com.intuit.craft.app.services.quickbook.management.domain"},
        exclude = {HibernateJpaAutoConfiguration.class})
public class QuickBookManagementApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        System.out.println("Main application is starting");
        SpringApplication.run(QuickBookManagementApplication.class, args);
    }
}
