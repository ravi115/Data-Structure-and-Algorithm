package com.intuit.craft.app.services.quickbook.management.api;

import com.intuit.craft.app.services.quickbook.management.domain.Product;

import java.util.List;

public interface ProductService {

    /**
     * @param product
     * @return
     */
    Product save(Product product);

    /**
     * @param productId
     * @return
     */
    Product get(String productId);

    /**
     * Get all products
     *
     * @return
     */
    List<Product> getAll();
}
