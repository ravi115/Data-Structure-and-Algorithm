package com.intuit.craft.app.services.quickbook.management.api;

import com.intuit.craft.app.services.quickbook.management.domain.Customer;

import java.util.List;

public interface CustomerService {

    /**
     * @param customer
     * @return
     */
    Customer save(Customer customer);

    /**
     * @param customerId
     * @return
     */
    Customer get(String customerId);

    /**
     * @param customer
     * @param customerId
     * @return
     */
    Customer update(Customer customer, String customerId);

    /**
     * @param customerId
     * @return
     */
    boolean delete(String customerId);

    /**
     * Get all the customers
     *
     * @return
     */
    List<Customer> getAll();
}
