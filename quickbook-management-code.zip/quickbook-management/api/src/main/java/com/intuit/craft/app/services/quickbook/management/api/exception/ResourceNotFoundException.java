package com.intuit.craft.app.services.quickbook.management.api.exception;

public class ResourceNotFoundException extends RuntimeException{

}
