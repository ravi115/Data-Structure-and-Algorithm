package com.intuit.craft.app.services.quickbook.management.api;

import com.intuit.craft.app.services.quickbook.management.domain.Product;

import java.util.List;

public interface ProductCatalogRepository {


    /**
     * check if product exist for the provided product id
     *
     * @param productId id of product
     * @return
     */
    boolean isProductExist(String productId);


    /**
     * fetch all the products.
     *
     * @return
     */
    List<Product> findAll();

    /**
     * fetch a product details for the provided product id
     *
     * @param productId
     * @return id of the product
     */
    Product findById(String productId);

    /**
     * insert a new product into product catalog
     *
     * @param product
     * @return
     */
    Product save(Product product);
}
