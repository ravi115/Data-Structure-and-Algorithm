package com.intuit.craft.app.services.quickbook.management.api;

import com.intuit.craft.app.services.quickbook.management.domain.Customer;

import java.util.List;

public interface CustomersCatalogRepository {

    /**
     * check if customer exist for the provided customer id
     *
     * @param customerId id of customer
     * @return
     */
    boolean isCustomerExist(String customerId);


    /**
     * fetch all the customers.
     *
     * @return
     */
    List<Customer> findAll();

    /**
     * fetch a customer details for the provided customer id
     *
     * @param customerId
     * @return id of the customer
     */
    Customer findById(String customerId);

    /**
     * insert a new customer into customer catalog
     *
     * @param customer
     * @return
     */
    Customer save(Customer customer);

    /**
     * update an existing customer
     *
     * @param customerId id of the customer
     * @param customer   updated customer details
     * @return
     */
    Customer update(String customerId, Customer customer);

    /**
     * delete a customer entity for the provided customer id
     *
     * @param customerId id of the customer
     * @return
     */
    boolean delete(String customerId);
}
