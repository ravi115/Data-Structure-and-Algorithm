package com.intuit.craft.app.services.quickbook.management.domain.converter;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intuit.craft.app.services.quickbook.management.domain.Product;

import java.util.List;

public class ProductsConverter implements DynamoDBTypeConverter<String, List<Product>> {

    @Override
    public String convert(List<Product> products) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(products);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Product list converter is failed");
        }
    }

    @Override
    public List<Product> unconvert(String strProductObject) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(strProductObject, new TypeReference<List<Product>>() {
            });
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Unable to un covert the product");
        }
    }
}
