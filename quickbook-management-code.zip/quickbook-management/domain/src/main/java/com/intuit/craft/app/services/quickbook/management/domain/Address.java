package com.intuit.craft.app.services.quickbook.management.domain;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import lombok.*;

@Data
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@DynamoDBDocument
public class Address {

    @DynamoDBAttribute(attributeName = "Line1")
    private String line1;

    @DynamoDBAttribute(attributeName = "Line2")
    private String line2;

    @DynamoDBAttribute(attributeName = "City")
    private String city;

    @DynamoDBAttribute(attributeName = "State")
    private String state;

    @DynamoDBAttribute(attributeName = "Zip")
    private String zip;

    @DynamoDBAttribute(attributeName = "Country")
    private String country;

}
