package com.intuit.craft.app.services.quickbook.management.impl;

import com.intuit.craft.app.services.quickbook.management.api.CustomerService;
import com.intuit.craft.app.services.quickbook.management.domain.Customer;
import com.intuit.craft.app.services.quickbook.management.domain.Product;
import com.intuit.craft.app.services.quickbook.management.impl.repository.CustomersCatalogRepositoryImpl;
import com.intuit.craft.app.services.quickbook.management.impl.repository.ProductCatalogRepositoryImpl;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

public class CustomerServiceImpl implements CustomerService {

    @Autowired
    CustomersCatalogRepositoryImpl customersCatalogRepositoryImpl;

    @Autowired
    ProductCatalogRepositoryImpl productCatalogRepositoryImpl;

    @Override
    public Customer save(Customer customer) {
        List<Product> products = customer.getProducts().stream()
                .map(Product::getProductId).map(productCatalogRepositoryImpl::findById)
                .collect(Collectors.toList());
        customer.setProducts(products);
        return customersCatalogRepositoryImpl.save(customer);
    }

    @Override
    public Customer get(String customerId) {
        return customersCatalogRepositoryImpl.findById(customerId);
    }

    @Override
    public Customer update(Customer customer, String customerId) {
        List<Product> products = customer.getProducts().stream()
                .map(Product::getProductId).map(productCatalogRepositoryImpl::findById)
                .collect(Collectors.toList());
        customer.setProducts(products);
        return customersCatalogRepositoryImpl.update(customerId, customer);
    }

    @Override
    public boolean delete(String customerId) {
        return customersCatalogRepositoryImpl.delete(customerId);
    }

    @Override
    public List<Customer> getAll() {
        return customersCatalogRepositoryImpl.findAll();
    }
}
