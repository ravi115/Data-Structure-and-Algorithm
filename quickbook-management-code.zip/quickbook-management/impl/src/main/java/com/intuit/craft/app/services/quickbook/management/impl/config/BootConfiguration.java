package com.intuit.craft.app.services.quickbook.management.impl.config;

import com.intuit.craft.app.services.quickbook.management.api.CustomerService;
import com.intuit.craft.app.services.quickbook.management.api.ProductService;
import com.intuit.craft.app.services.quickbook.management.impl.CustomerServiceImpl;
import com.intuit.craft.app.services.quickbook.management.impl.ProductServiceImpl;
import com.intuit.craft.app.services.quickbook.management.impl.repository.CustomersCatalogRepositoryImpl;
import com.intuit.craft.app.services.quickbook.management.impl.repository.ProductCatalogRepositoryImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
public class BootConfiguration {

    @Lazy
    @Bean
    CustomerService getCustomerService() {
        return new CustomerServiceImpl();
    }

    @Lazy
    @Bean
    ProductService getProductService() {
        return new ProductServiceImpl();
    }

    @Lazy
    @Bean
    ProductCatalogRepositoryImpl getProductRepository() {
        return new ProductCatalogRepositoryImpl();
    }

    @Lazy
    @Bean
    CustomersCatalogRepositoryImpl getCustomerRepository() {
        return new CustomersCatalogRepositoryImpl();
    }
}
