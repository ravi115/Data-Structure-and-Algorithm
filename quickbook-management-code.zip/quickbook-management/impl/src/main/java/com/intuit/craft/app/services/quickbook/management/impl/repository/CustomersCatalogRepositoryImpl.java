package com.intuit.craft.app.services.quickbook.management.impl.repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedList;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.intuit.craft.app.services.quickbook.management.api.CustomersCatalogRepository;
import com.intuit.craft.app.services.quickbook.management.domain.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import java.util.ArrayList;
import java.util.List;

public class CustomersCatalogRepositoryImpl implements CustomersCatalogRepository {

    @Lazy
    @Autowired
    private DynamoDBMapper dynamoDBMapper;


    @Override
    public boolean isCustomerExist(String customerId) {
        try {
            return dynamoDBMapper.load(Customer.class, customerId) != null;
        } catch (Exception e) {
            throw new RuntimeException("Customer with customerId= " + customerId + " doesn't exist", e);
        }

    }

    @Override
    public List<Customer> findAll() {
        try {
            PaginatedList<Customer> customerPaginatedList = dynamoDBMapper.scan(Customer.class, new DynamoDBScanExpression());
            return new ArrayList<>(customerPaginatedList);
        } catch (Exception e) {
            throw new RuntimeException("Unable to load customers", e);
        }
    }

    @Override
    public Customer findById(String customerId) {
        try {
            return dynamoDBMapper.load(Customer.class, customerId);
        } catch (Exception e) {
            throw new RuntimeException("Unable to load customers with customer id= " + customerId, e);
        }
    }

    public Customer save(Customer customer) {
        try {
            dynamoDBMapper.save(customer);
        } catch (Exception e) {
            throw new RuntimeException("Unable to save customer", e);
        }
        return customer;
    }

    @Override
    public Customer update(String customerId, Customer customer) {
        try {
            dynamoDBMapper.save(customer,
                    new DynamoDBSaveExpression()
                            .withExpectedEntry("CustomerId",
                                    new ExpectedAttributeValue(
                                            new AttributeValue().withS(customerId)
                                    )));
            return customer;
        } catch (Exception e) {
            throw new RuntimeException("Unable to update customer with customerId= " + customerId, e);
        }
    }

    @Override
    public boolean delete(String customerId) {
        try {
            dynamoDBMapper.delete(dynamoDBMapper.load(Customer.class, customerId));
            return true;
        } catch (Exception e) {
            throw new RuntimeException("Unable to delete customer with customer id=" + customerId, e);
        }
    }

}
