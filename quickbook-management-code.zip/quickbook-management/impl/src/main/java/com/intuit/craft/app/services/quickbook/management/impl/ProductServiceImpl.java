package com.intuit.craft.app.services.quickbook.management.impl;

import com.intuit.craft.app.services.quickbook.management.api.ProductService;
import com.intuit.craft.app.services.quickbook.management.domain.Product;
import com.intuit.craft.app.services.quickbook.management.impl.repository.ProductCatalogRepositoryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import java.util.List;

public class ProductServiceImpl implements ProductService {

    @Lazy
    @Autowired
    ProductCatalogRepositoryImpl productCatalogRepositoryImpl;

    @Override
    public Product save(Product product) {
        return productCatalogRepositoryImpl.save(product);
    }

    @Override
    public Product get(String productId) {
        return productCatalogRepositoryImpl.findById(productId);
    }

    @Override
    public List<Product> getAll() {
        return productCatalogRepositoryImpl.findAll();
    }
}
