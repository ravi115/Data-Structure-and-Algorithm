package com.intuit.craft.app.services.quickbook.management.impl.repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedList;
import com.intuit.craft.app.services.quickbook.management.api.ProductCatalogRepository;
import com.intuit.craft.app.services.quickbook.management.domain.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import java.util.ArrayList;
import java.util.List;

public class ProductCatalogRepositoryImpl implements ProductCatalogRepository {

    @Lazy
    @Autowired
    private DynamoDBMapper dynamoDBMapper;

    @Override
    public boolean isProductExist(String productId) {
        try {
            return dynamoDBMapper.load(productId) != null;
        } catch (Exception e) {
            throw new RuntimeException("Product not found with productId= " + productId, e);
        }
    }

    @Override
    public List<Product> findAll() {
        try {
            PaginatedList<Product> productPaginatedScanList = dynamoDBMapper.scan(Product.class, new DynamoDBScanExpression());
            return new ArrayList<>(productPaginatedScanList);
        } catch (Exception e) {
            throw new RuntimeException("Unable to load products", e);
        }
    }

    @Override
    public Product findById(String productId) {
        try {
            return dynamoDBMapper.load(Product.class, productId);
        } catch (Exception e) {
            throw new RuntimeException("Unable to load product with productId= " + productId, e);
        }
    }

    public Product save(Product product) {
        try {
            dynamoDBMapper.save(product);
            return product;
        } catch (Exception e) {
            throw new RuntimeException("Unable to save product", e);
        }
    }
}
